# fbcmd4j
REPOSITORIO COMPUTACION EN JAVA EVIDENCIA FINAL

## INSTALACION
Instalar JDK 8 en su versi�n m�s reciente. 
Crear una cuenta en GitHub como usuario normal o estudiante (https://education.github.com/) con tu cuenta de correo. 
Instalar GitHub para Escritorio o Git en l�nea de comando. 
Instalar un IDE de acuerdo a los mencionados (Eclipse, NetBeans, IntelliJIDEA).
Crear un repositorio en GitHub con tu cuenta bajo el nombre de fbcmd4j



## REQUERIMIENTOS
Archivo README.md con los siguientes elementos: 
Instalaci�n 
Uso
Cr�ditos 
Licencia  o Archivo .gitignore para ignorar los archivos .class, .swp y los archivos de proyecto de tu IDE seleccionado. 
Crear un branch llamado develop donde se registrar�n todos los cambios en tu c�digo.
Configurar el IDE instalado para manejar tu repositorio en GitHub. 



## USO
En la linea de comando de la terminal de su equipo, ejecute el comando fbcm4j , el cual mostrara las siguientes opciones:

Obtener NewsFeed
Obtener Wall
Publicar estado en el Wall
Publicar link en el Wall
Terminar el programa
Usted simplemente selecciona la opci�n que desea ejecutar.
 

## CREDITOS
Ingeniero  Jose Manuel Lopez Lujan

Ingeniera Lorenza Illanes Diaz Rivera 

Desarrollado por Diana Karina Jasso Monge

## LICENCIA

Este proyecto se apega al esquema de licenciamiento expuesto en el documento licencia de MIT
